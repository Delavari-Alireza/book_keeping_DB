create table LUSER(
   USER_id INT NOT NULL AUTO_INCREMENT,
   UserName VARCHAR(100) NOT NULL,
   Feild VARCHAR(100),
   LatestDegree VARCHAR(100),
   UserImage VARCHAR(100),
   UserPassword VARCHAR(40) NOT NULL,
   Email VARCHAR(100) NOT NULL,
   BirthYear DATE,
   PRIMARY KEY ( USER_id )
);

create table LADMIN(
   Admin_id INT NOT NULL AUTO_INCREMENT,
   AdminName VARCHAR(100) NOT NULL,
   Image VARCHAR(100),
   AdminPassword VARCHAR(40) NOT NULL,
   Email VARCHAR(100) NOT NULL,
   PRIMARY KEY ( Admin_id )
);

create table BOOK(
   Book_id INT NOT NULL AUTO_INCREMENT,
   BookName VARCHAR(100) NOT NULL,
   writer VARCHAR(100),
   publisher VARCHAR(100),
   publishYear INT ,
   Book_craeted_year date DEFAULT (CURRENT_DATE),
   entity INT NOT NULL CHECK(entity >= 0),
   Genre VARCHAR(100),
   score INT CHECK(score > 0 and score <= 5),
   User_id_comment INT,
   Comment_date date,
   User_id_score INT,
   User_id_rent INT,
   rent_date date,
   User_id_return INT,
   return_date date,
   Admin_id_remover INT,
   Admin_id_creator INT,
   Admin_id_editor INT,

   PRIMARY KEY ( Book_id ),
   
   FOREIGN KEY (User_id_comment)
      REFERENCES LUSER(USER_id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
   FOREIGN KEY (User_id_score)
      REFERENCES LUSER(USER_id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
	FOREIGN KEY (User_id_rent)
      REFERENCES LUSER(USER_id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
	FOREIGN KEY (User_id_return)
      REFERENCES LUSER(USER_id)
      ON UPDATE CASCADE ON DELETE RESTRICT,
      
	FOREIGN KEY (Admin_id_remover)
      REFERENCES LADMIN(Admin_id)
      ON UPDATE CASCADE ,
      
	FOREIGN KEY (Admin_id_creator)
      REFERENCES LADMIN(Admin_id)
      ON UPDATE CASCADE ,
      
	FOREIGN KEY (Admin_id_editor)
      REFERENCES LADMIN(Admin_id)
      ON UPDATE CASCADE 
);

INSERT INTO LADMIN (Admin_id, AdminName, Image, AdminPassword, Email)
VALUES (1, 'ادمین ادمینیان', null, '1234', 'Admin@gmail.com');