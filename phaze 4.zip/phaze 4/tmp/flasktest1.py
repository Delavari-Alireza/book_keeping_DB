

import traceback
from flask import Flask
from flask import render_template, redirect, url_for, request , flash
from datetime import datetime
import pymysql
app = Flask(__name__)


current_user_id = -1
is_Admin = False

@app.route('/')
def start():
   return redirect(url_for('login'))



@app.route('/BookDetail/BookRent/<int:id>')
def BookRent(id):
   result = ""
   try:
      with connection.cursor() as cursor:
         sql = "UPDATE `BOOK` set `entity` = `entity` - %s , `User_id_rent` = %s ,rent_date = %s WHERE `Book_id` = %s"
        
         cursor.execute(sql , (id , current_user_id , datetime.now()))
         connection.commit()
         traceback.print_exc()
         return redirect(url_for('UserPage'))
   except:
      flash("smething went worng")
      return "smething went worng"

@app.route('/UserBookList')
def UserBookList():
   result = ""    
   with connection.cursor() as cursor:
      # Read a single record
      sql = "SELECT * FROM `Book`"
      cursor.execute(sql)
      result = cursor.fetchall()
      
      if (result == None):
             
         return "کتابی در سیستم موجود نیست."
  
        #A = result["UserName"]
        #print(A)
   return  render_template('UserBookList.html',results = result)

@app.route('/UserSearchBook')
def UserSearchBook():
   result = ""  
   if request.method == 'POST':
      searched = request.form.get('search')  
      with connection.cursor() as cursor:
         # Read a single record
         sql = "SELECT * FROM `Book` where BookName LIKE '%%s%'"
         cursor.execute(sql , (searched))
         result = cursor.fetchall()
         print(result)
         return render_template('UserSearchBook.html',results = result)

         #for row in records:
         #       print("Id: ", row[0])
         #   print("Name: ", row[1])
         #   print("Email: ", row[2])
         #   print("Salary: ", row[3])
         #   print("\n")
         #A = result["UserName"]
         #print(A)
   return  render_template('UsersearchBook.html')


@app.route('/BookDetail/<int:id>')
def BookDetail(id):
   result = ""
   with connection.cursor() as cursor:
      # Read a single record
      sql = "SELECT * FROM `Book` where Book_id= %s"
      cursor.execute(sql,(id))
      result = cursor.fetchall()
      
      if (result == None):
             
         return "کتابی در سیستم موجود نیست."
  
        #A = result["UserName"]
        #print(A)
   return  render_template('BookDetail.html',results = result)



#DELETE FROM lusers WHERE user_id = id;
@app.route('/Admin/BookUpdate/<int:id>' , methods=['GET', 'POST'])
def BookUpdate(id ):
   result = ""
   if request.method == 'POST':
      BookName = request.form.get('BookName')
      writer = request.form.get('writer')
      if writer == "":
            writer = None
      
      publisher = request.form.get('publisher')
      if publisher == "":
            publisher = None
      publishYear = request.form.get('publishYear')
      if publishYear == "":
            publishYear = None
      Genre = request.form.get('Genre')
      if Genre == "":
            Genre = None
      entity = request.form.get('entity')
      
      try:
         with connection.cursor() as cursor:
            sql = "UPDATE `BOOK` SET `BookName` = %s, `writer`= %s, `publisher`= %s, `publishYear`= %s, `Genre`= %s, `entity`= %s, `score`= %s , `Admin_id_creator`= %s) WHERE Book_id= %s"
            cursor.execute(sql, (BookName, writer, publisher,publishYear, Genre, entity , 1 , 1, id))
            connection.commit()
            flash('ذخیره شد')
      except:
         traceback.print_exc()
         flash('نشد که بشود')
      return redirect(url_for('AdminPage'))
   try:
      with connection.cursor() as cursor:
         
         sql = " SELECT * FROM `BOOK` WHERE `Book_id` = %s"
         cursor.execute(sql , (id))
         result = cursor.fetchall()
         if result == None:
                return "ok"
         traceback.print_exc()
         return render_template('BookUpdate.html',result = result)   
            
   except:
      flash("مشکلی پیش آمده است")
      return "مشکلی پیش امده است"

@app.route('/Admin/BookDelete/<int:id>')
def BookDelete(id):
   result = ""
   try:
      with connection.cursor() as cursor:
         
         sql = "DELETE FROM `BOOK` where `Book_id` = %s"
         cursor.execute(sql , (id))
         connection.commit()
         return redirect(url_for('BookList'))
   except:
      flash("smething went worng")
      return "smething went worng"


@app.route('/Admin/userDelete/<int:id>')
def userDelete(id):
   result = ""
   try:
      with connection.cursor() as cursor:
         
         sql = "DELETE FROM `LUSER` where `user_id` = %s"
         cursor.execute(sql , (id))
         connection.commit()
         return redirect(url_for('users'))
   except:
      flash("smething went worng")
      return "smething went worng"
      
@app.route('/Admin/userUpdate/<int:id>' , methods=['GET', 'POST'])
def userUpdate(id ):
   result = ""
   if request.method == 'POST':
      email = request.form.get('email')
      name = request.form.get('name')
      password = request.form.get('password')
      field = request.form.get('field')
      if field == "":
            field = None
      LatestDegree = request.form.get('LatestDegree')
      if LatestDegree == "":
            LatestDegree = None
      BirthYear = request.form.get('BirthYear')
      if BirthYear == "":
            BirthYear = None
      try:
         with connection.cursor() as cursor:


            sql = "UPDATE `LUSER` set `UserName` = %s , `Feild` = %s , `LatestDegree` = %s , `UserPassword` = %s , `Email`=%s,  `BirthYear` = %s where `USER_id` = %s"
            cursor.execute(sql, (name, field, LatestDegree, password, email, datetime.now(), id))
            connection.commit()
            traceback.print_exc()
      except:
         flash('نشد که بشود')
      return redirect(url_for('login'))
   try:
      with connection.cursor() as cursor:
         
         sql = " SELECT `UserName` ,`Feild` , `LatestDegree` , `UserPassword`, `Email` , `BirthYear`  FROM `LUSER` WHERE `USER_id` = %s"
         cursor.execute(sql , (id))
         result = cursor.fetchall()
         if result == None:
                return "ok"
         traceback.print_exc()
         return render_template('UserUpdate.html',result = result)   
            
   except:
      flash("مشکلی پیش آمده است")
      return "مشکلی پیش امده است"


@app.route('/searchBook', methods=['GET', 'POST'])
def searchBook():
   result = ""  
   if request.method == 'POST':
      searched = request.form.get('search')  
      with connection.cursor() as cursor:
         # Read a single record
         sql = "SELECT * FROM `Book` where BookName LIKE '%%s%'"
         cursor.execute(sql , (searched))
         result = cursor.fetchall()
         print(result)
         return render_template('searchBook.html',results = result)

         #for row in records:
         #       print("Id: ", row[0])
         #   print("Name: ", row[1])
         #   print("Email: ", row[2])
         #   print("Salary: ", row[3])
         #   print("\n")
         #A = result["UserName"]
         #print(A)
   return  render_template('searchBook.html')

@app.route('/Admin/BookList')
def BookList():
   result = ""    
   with connection.cursor() as cursor:
      # Read a single record
      sql = "SELECT * FROM `Book`"
      cursor.execute(sql)
      result = cursor.fetchall()
      print(result)
      if (result == None):
             
         return "کتابی در سیستم موجود نیست."
  
        #A = result["UserName"]
        #print(A)
   return  render_template('BookList.html',results = result)

@app.route('/EditUser')
def EditUser():
   result = ""
   if request.method == 'POST':
      email = request.form.get('email')
      name = request.form.get('name')
      password = request.form.get('password')
      field = request.form.get('field')
      if field == "":
            field = None
      LatestDegree = request.form.get('LatestDegree')
      if LatestDegree == "":
            LatestDegree = None
      BirthYear = request.form.get('BirthYear')
      if BirthYear == "":
            BirthYear = None
      try:
         with connection.cursor() as cursor:


            sql = "UPDATE `LUSER` set `UserName` = %s , `Feild` = %s , `LatestDegree` = %s , `UserPassword` = %s , `Email`=%s,  `BirthYear` = %s where `USER_id` = %s"
            cursor.execute(sql, (name, field, LatestDegree, password, email, datetime.now(),id))
            connection.commit()
            traceback.print_exc()
      except:
         flash('نشد که بشود')
      return redirect(url_for('login'))
   try:
      with connection.cursor() as cursor:
         
         sql2 = " SELECT `UserName` ,`Feild` , `LatestDegree` , `UserPassword`, `Email` , `BirthYear`  FROM `LUSER` WHERE `user_id` = %s"
         cursor.execute(sql2 , (current_user_id))
         result = cursor.fetchall()
         if result == None:
                return "ok"
         traceback.print_exc()
         return render_template('EditUser.html',result = result)   
            
   except:
      flash("مشکلی پیش آمده است")
      return "مشکلی پیش امده است"

#@app.route('/UserBookList')
#def UserBookList():
#   result = ""    
#   with connection.cursor() as cursor:
#      # Read a single record
 #     sql = "SELECT * FROM `Book`"
#      cursor.execute(sql)
#      result = cursor.fetchall()
#      print(result)
#      if (result == None):
             
#         return "کتابی در سیستم موجود نیست."
  
        #A = result["UserName"]
        #print(A)
#   return  render_template('UserBookList.html',results = result)

@app.route('/Admin/users')
def users():
   result = ""    
   with connection.cursor() as cursor:
      # Read a single record
      sql = "SELECT * FROM `LUSER`"
      cursor.execute(sql)
      result = cursor.fetchall()
      
      if (result == None):
             
         return "کاربری در سیستم موجود نیست."
  
        #A = result["UserName"]
        #print(A)
   return  render_template('users.html',results = result)


@app.route('/Admin')
def AdminPage():
   #if is_Admin == False:
   #   return redirect(url_for('login'))
   result = ""    
   with connection.cursor() as cursor:
        # Read a single record
        sql = "SELECT * FROM `LADMIN`"
        cursor.execute(sql)
        result = cursor.fetchall()
        if type(result) == list:
            return render_template('AdminPage.html',result = result)    

   return render_template('AdminPage.html',result = result)

@app.route('/user')
def UserPage():
   #if is_Admin == False:
   #   return redirect(url_for('login'))
   result = ""    
   with connection.cursor() as cursor:
        # Read a single record
        sql = "SELECT * FROM `LUSER` WHERE `USER_id` = %s"
        cursor.execute(sql, (current_user_id))
        result = cursor.fetchall()

   return render_template('UserPage.html',result = result)

@app.route('/AddBook', methods=['GET', 'POST'])
def AddBook():
   #if is_Admin == False:
   #       return redirect(url_for('login'))
   if request.method == 'POST':
      BookName = request.form.get('BookName')
      writer = request.form.get('writer')
      if writer == "":
            writer = None
      
      publisher = request.form.get('publisher')
      if publisher == "":
            publisher = None
      publishYear = request.form.get('publishYear')
      if publishYear == "":
            publishYear = None
      Genre = request.form.get('Genre')
      if Genre == "":
            Genre = None
      entity = request.form.get('entity')
      
      try:
         with connection.cursor() as cursor:
            sql = "INSERT INTO `BOOK` (`BookName`, `writer`, `publisher`, `publishYear`, `Genre`, `entity`, `score`  , `Admin_id_creator`) VALUES (%s,%s,%s,%s,%s, %s,%s,%s)"
            cursor.execute(sql, (BookName, writer, publisher,publishYear, Genre, entity , 1 , 1))
            connection.commit()
            flash('ذخیره شد')
      except:
         traceback.print_exc()
         flash('نشد که بشود')
      return redirect(url_for('AddBook'))


   return render_template('AddBook.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    result = ""
    error = None
    password = None
    if request.method == 'POST':
        with connection.cursor() as cursor: 
         """CHECK USER :"""
         
         sql = "SELECT `UserPassword`, `USER_id` FROM `LUSER` WHERE `Email`=%s"
         cursor.execute(sql, (request.form['username'],))
         result = cursor.fetchone()

         try:
            password = result["UserPassword"]
         except :
            pass
         
         if password is None:
               error = 'اشتباه است.'
         elif password == request.form['password']:
                  
               """ success USER"""
               current_user_id = result["USER_id"]
               return redirect(url_for('UserPage'))

         else:      
               error = 'اشتباه است.'


         """CHECK Admin :"""

         sql = "SELECT `AdminPassword` FROM `LADMIN` WHERE `Email`=%s"
         cursor.execute(sql, (request.form['username'],))
         result = cursor.fetchone()
         

         try:
            password = result["AdminPassword"]
         except :
            pass


         if password is None:
               error = 'اشتباه است.'
         elif password == request.form['password']:
                  
               """ success """
               is_Admin = True
               return redirect(url_for('AdminPage'))

         else:
               error = 'اشتباه است.'


    return render_template('login.html', error=error)



@app.route('/signup', methods=['GET', 'POST'])
def signup():
   result = ""
   error = None

   #if email == none and name == none and password ==none:
   #   return render_template('signup.html', error=error)    
   if request.method == 'POST':
      email = request.form.get('email')
      name = request.form.get('name')
      password = request.form.get('password')
      field = request.form.get('field')
      if field == "":
            field = None
      LatestDegree = request.form.get('LatestDegree')
      if LatestDegree == "":
            LatestDegree = None
      BirthYear = request.form.get('BirthYear')
      if BirthYear == "":
            BirthYear = None
      try:
         with connection.cursor() as cursor:
            # Create a new record
            #sql = "INSERT INTO `LADMIN` (`UserName`, `UserPassword`, `Email`) VALUES (%s,%s,%s)"
            #cursor.execute(sql, (str(name1), str(password), str(email)))
            #return render_template('login.html')
            sql = "INSERT INTO `LUSER` (`UserName`, `Feild`, `LatestDegree`, `UserPassword`, `Email`, `BirthYear`) VALUES (%s,%s,%s,%s,%s, %s)"
            cursor.execute(sql, (name, field, LatestDegree, password, email, datetime.now()))
            connection.commit()
      except:
         flash('نشد که بشود')
      return redirect(url_for('login'))


   return render_template('signup.html', error=error)









if __name__ == '__main__':
       
   app.secret_key = 'super secret key'
   app.config['SESSION_TYPE'] = 'filesystem'


   connection = pymysql.connect(host='localhost',
                             user='root',
                             password='s4C6Xq6Gf0ad',
                             database='libarary',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

   



   app.run(debug=True)